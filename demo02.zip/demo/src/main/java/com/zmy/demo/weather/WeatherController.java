package com.zmy.demo.weather;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 天气查询接口（对接心知天气）。用于验证 WeatherService 能否正常获取天气。
 */
@RestController
@RequestMapping("/weather")
public class WeatherController {

    private final WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    /** 实时天气查询。示例：/weather/now?location=郑州 */
    @GetMapping("/now")
    public ResponseEntity<Map<String, Object>> now(@RequestParam("location") String location) {
        if (location == null || location.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "location 不能为空"));
        }
        try {
            WeatherService.WeatherInfo info = weatherService.getNowWeather(location);
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "city", info.city(),
                    "path", info.path(),
                    "text", info.text(),
                    "code", info.code(),
                    "temperature", info.temperature(),
                    "lastUpdate", info.lastUpdate()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("success", false, "message", String.valueOf(e.getMessage())));
        }
    }
}