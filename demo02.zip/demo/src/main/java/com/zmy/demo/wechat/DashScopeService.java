package com.zmy.demo.wechat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 阿里云百炼（DashScope）LLM 能力封装：
 * <ul>
 *   <li>chat —— OpenAI 兼容对话接口（qwen 系列）</li>
 *   <li>generateImage —— wanx 文生图（异步任务，轮询结果后下载图片字节）</li>
 * </ul>
 */
@Service
public class DashScopeService {

    private static final Logger log = LoggerFactory.getLogger(DashScopeService.class);

    private static final String BASE_URL = "https://dashscope.aliyuncs.com";
    private static final String CHAT_URL = BASE_URL + "/compatible-mode/v1/chat/completions";
    private static final String IMAGE_CREATE_URL = BASE_URL + "/api/v1/services/aigc/text2image/image-synthesis";
    private static final String TASK_URL = BASE_URL + "/api/v1/tasks/";
    private static final String TTS_URL = BASE_URL + "/api/v1/services/audio/tts/SpeechSynthesizer";

    private final ObjectMapper mapper = new ObjectMapper();
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build();

    @Value("${dashscope.api-key:}")
    private String apiKey;

    @Value("${dashscope.chat-model:qwen-plus}")
    private String chatModel;

    @Value("${dashscope.enable-search:true}")
    private boolean enableSearch;

    @Value("${dashscope.forced-search:true}")
    private boolean forcedSearch;

    @Value("${dashscope.search-extension:true}")
    private boolean searchExtension;

    @Value("${dashscope.image-model:wanx2.1-t2i-turbo}")
    private String imageModel;

    @Value("${dashscope.image-size:1024*1024}")
    private String imageSize;

    @Value("${dashscope.vision-model:qwen-vl-plus}")
    private String visionModel;

    @Value("${dashscope.tts-model:qwen-audio-3.0-tts-flash}")
    private String ttsModel;

    @Value("${dashscope.tts-voice:longanhuan_v3.6}")
    private String ttsVoice;

    /** 文本对话，返回模型回复内容 */
    public String chat(String userText) throws IOException {
        requireKey();
        ObjectNode body = mapper.createObjectNode();
        body.put("model", chatModel);
        if (enableSearch && needsWebSearch(userText) && !looksLikeWeatherQuestion(userText)) {
            body.put("enable_search", true);
            ObjectNode searchOptions = body.putObject("search_options");
            if (forcedSearch) {
                searchOptions.put("forced_search", true);
            }
            if (searchExtension) {
                searchOptions.put("enable_search_extension", true);
            }
        }
        ArrayNode messages = body.putArray("messages");
        ObjectNode user = messages.addObject();
        user.put("role", "user");
        user.put("content", userText);

        JsonNode resp = postJson(CHAT_URL, body);
        String reply = resp.path("choices").path(0).path("message").path("content").asText("");
        if (reply.isEmpty()) {
            throw new IOException("对话返回为空: " + resp);
        }
        return reply;
    }

    /**
     * 对话 + 自动判断是否生成图片（函数调用）。
     * 用户要求画图时，模型会调用 generate_image 工具，返回图片提示词；否则返回文本回复。
     */
    public ChatResult chatOrGenerate(String userText) throws IOException {
        requireKey();
        ObjectNode body = mapper.createObjectNode();
        body.put("model", chatModel);
        if (enableSearch && needsWebSearch(userText) && !looksLikeWeatherQuestion(userText)) {
            body.put("enable_search", true);
            ObjectNode searchOptions = body.putObject("search_options");
            if (forcedSearch) {
                searchOptions.put("forced_search", true);
            }
            if (searchExtension) {
                searchOptions.put("enable_search_extension", true);
            }
        }

        ArrayNode messages = body.putArray("messages");
        ObjectNode system = messages.addObject();
        system.put("role", "system");
        system.put("content",
                "你是微信机器人助手。当用户要求生成、绘制、创作图片时，必须调用 generate_image 工具；"
                        + "当用户要求语音播报、语音回复、把文字读出来时，必须调用 speak_text 工具；"
                        + "当用户询问某个地点的实时/当前天气时，必须调用 query_weather 工具获取准确天气数据，"
                        + "不要自己编造天气，也不要联网搜索天气。"
                        + "注意：如果用户询问的是省份、自治区等省级区域（如'河南天气'、'广东省天气'）的天气，不要调用 query_weather 工具，"
                        + "而应提示用户：该查询仅支持具体城市，请提供具体的城市名称（如'郑州'、'广州'）。"
                        + "绝对不要用文字回答'无法生成图片'或'无法播放语音'。其他情况正常文字回复。");
        ObjectNode user = messages.addObject();
        user.put("role", "user");
        user.put("content", userText);

        // 定义 generate_image 工具
        ObjectNode tool = body.putArray("tools").addObject();
        tool.put("type", "function");
        ObjectNode fn = tool.putObject("function");
        fn.put("name", "generate_image");
        fn.put("description", "生成一张图片（文生图）。当用户要求画图、生成图片、创作插图/海报等时调用。");
        ObjectNode params = fn.putObject("parameters");
        params.put("type", "object");
        ObjectNode promptProp = params.putObject("properties").putObject("prompt");
        promptProp.put("type", "string");
        promptProp.put("description", "图片内容的详细描述（中文）");
        params.putArray("required").add("prompt");

        // 定义 speak_text 工具（语音播报）
        ObjectNode tool2 = body.putArray("tools").addObject();
        tool2.put("type", "function");
        ObjectNode fn2 = tool2.putObject("function");
        fn2.put("name", "speak_text");
        fn2.put("description", "把文字用语音播报/朗读出来，用于语音回复。当用户要求语音回复、播放语音、读出文字时调用。");
        ObjectNode params2 = fn2.putObject("parameters");
        params2.put("type", "object");
        ObjectNode textProp = params2.putObject("properties").putObject("text");
        textProp.put("type", "string");
        textProp.put("description", "要说的话（中文）");
        params2.putArray("required").add("text");

        // 定义 query_weather 工具（准确天气）
        ObjectNode tool3 = body.putArray("tools").addObject();
        tool3.put("type", "function");
        ObjectNode fn3 = tool3.putObject("function");
        fn3.put("name", "query_weather");
        fn3.put("description", "查询某个城市的实时天气（当前天气情况）。当用户询问某城市的当前或实时天气时调用，例如'郑州天气怎么样'、'上海现在热吗'。仅支持具体城市，不支持省份、自治区等省级区域——用户询问省级天气时不要调用本工具，应提示用户提供具体城市名。");
        ObjectNode params3 = fn3.putObject("parameters");
        params3.put("type", "object");
        ObjectNode locProp = params3.putObject("properties").putObject("location");
        locProp.put("type", "string");
        locProp.put("description", "地点：必须是具体城市名（如：郑州、上海）或城市拼音（如：zhengzhou），不能是省份、自治区等省级区域");
        params3.putArray("required").add("location");
        body.put("tool_choice", "auto");

        JsonNode resp = postJson(CHAT_URL, body);
        JsonNode message = resp.path("choices").path(0).path("message");

        // 解析工具调用
        JsonNode toolCalls = message.path("tool_calls");
        if (toolCalls.isArray()) {
            for (JsonNode tc : toolCalls) {
                String functionName = tc.path("function").path("name").asText("");
                String arguments = tc.path("function").path("arguments").asText("");
                if ("generate_image".equals(functionName)) {
                    String prompt = extractArgument(arguments, "prompt");
                    if (prompt != null && !prompt.isBlank()) {
                        return new ChatResult(null, prompt, null, null);
                    }
                }
                if ("speak_text".equals(functionName)) {
                    String speech = extractArgument(arguments, "text");
                    if (speech != null && !speech.isBlank()) {
                        return new ChatResult(null, null, speech, null);
                    }
                }
                if ("query_weather".equals(functionName)) {
                    String location = extractArgument(arguments, "location");
                    if (location != null && !location.isBlank()) {
                        return new ChatResult(null, null, null, location);
                    }
                }
            }
        }

        String reply = message.path("content").asText("");
        if (reply.isEmpty()) {
            throw new IOException("对话返回为空: " + resp);
        }
        return new ChatResult(reply, null, null, null);
    }

    /** 文生图，返回图片字节与文件名 */
    public ImageResult generateImage(String prompt) throws IOException, InterruptedException {
        requireKey();
        ObjectNode body = mapper.createObjectNode();
        body.put("model", imageModel);
        body.putObject("input").put("prompt", prompt);
        ObjectNode params = body.putObject("parameters");
        params.put("size", imageSize);
        params.put("n", 1);

        JsonNode createResp = postJson(IMAGE_CREATE_URL, body, "X-DashScope-Async", "enable");
        String taskId = createResp.path("output").path("task_id").asText("");
        if (taskId.isEmpty()) {
            throw new IOException("文生图任务提交失败: " + createResp);
        }
        log.info("文生图任务已提交，taskId = {}", taskId);

        // 每 3 秒轮询一次，最多约 3 分钟
        String imageUrl = null;
        for (int i = 0; i < 60; i++) {
            Thread.sleep(3000);
            JsonNode task = getJson(TASK_URL + taskId);
            String status = task.path("output").path("task_status").asText("");
            if ("SUCCEEDED".equals(status)) {
                imageUrl = task.path("output").path("results").path(0).path("url").asText(null);
                break;
            }
            if ("FAILED".equals(status) || "CANCELED".equals(status) || "CANCELLED".equals(status)) {
                throw new IOException("文生图任务失败: " + task);
            }
        }
        if (imageUrl == null) {
            throw new IOException("文生图任务超时");
        }

        byte[] bytes = download(imageUrl);
        return new ImageResult(bytes, "image" + extensionOf(imageUrl));
    }

    /** 图片理解：调用视觉模型识别图片内容，返回文字描述 */
    public String describeImage(byte[] imageBytes, String fileName, String prompt) throws IOException {
        requireKey();
        ObjectNode body = mapper.createObjectNode();
        body.put("model", visionModel);
        ArrayNode messages = body.putArray("messages");
        ObjectNode user = messages.addObject();
        user.put("role", "user");
        ArrayNode content = user.putArray("content");

        ObjectNode imagePart = content.addObject();
        imagePart.put("type", "image_url");
        imagePart.putObject("image_url").put("url", dataUrlOf(imageBytes, fileName));

        ObjectNode textPart = content.addObject();
        textPart.put("type", "text");
        textPart.put("text", prompt == null || prompt.isBlank() ? "请详细描述这张图片的内容" : prompt);

        JsonNode resp = postJson(CHAT_URL, body);
        String reply = resp.path("choices").path(0).path("message").path("content").asText("");
        if (reply.isEmpty()) {
            throw new IOException("图片识别返回为空: " + resp);
        }
        return reply;
    }

    /** 语音合成：TTS 生成 mp3 音频（用于作为文件发送，安全稳妥） */
    public VoiceResult synthesizeVoice(String text) throws IOException {
        requireKey();
        ObjectNode body = mapper.createObjectNode();
        body.put("model", ttsModel);
        ObjectNode input = body.putObject("input");
        input.put("text", text);
        input.put("voice", ttsVoice);
        input.put("format", "mp3");

        JsonNode resp = postJson(TTS_URL, body);
        String audioUrl = resp.path("output").path("audio").path("url").asText("");
        if (audioUrl.isEmpty()) {
            throw new IOException("语音合成失败: " + resp);
        }
        byte[] mp3 = download(audioUrl);
        log.info("语音合成完成（{} 字节）", mp3.length);
        return new VoiceResult(mp3, "reply.mp3");
    }

    private static String extractArgument(String arguments, String key) {
        try {
            return new ObjectMapper().readTree(arguments).path(key).asText("");
        } catch (Exception e) {
            return "";
        }
    }

    private static String dataUrlOf(byte[] bytes, String fileName) {
        return "data:" + mimeOf(fileName) + ";base64," + java.util.Base64.getEncoder().encodeToString(bytes);
    }

    private static String mimeOf(String fileName) {
        String name = fileName == null ? "" : fileName.toLowerCase(Locale.ROOT);
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".gif")) return "image/gif";
        if (name.endsWith(".webp")) return "image/webp";
        if (name.endsWith(".bmp")) return "image/bmp";
        return "image/jpeg";
    }

    /** 实时/热点类关键词：命中则本次对话联网搜索，普通聊天不搜 */
    private static final Set<String> SEARCH_KEYWORDS = Set.of(
            "新闻", "热点", "资讯",
            "股票", "股价", "大盘", "行情", "沪指", "深指", "纳斯达克",
            "汇率", "美元", "欧元", "日元", "英镑",
            "油价", "汽油", "柴油",
            "金价", "黄金", "银价",
            "彩票", "双色球", "大乐透", "开奖",
            "限行", "车牌",
            "赛事", "比赛", "比分", "赛程", "排名", "英超", "西甲", "NBA", "世界杯",
            "今天", "明天", "后天", "昨天", "实时", "现在", "当前", "最新", "近期", "最近",
            "农历", "几号", "星期几", "几点");

    private static boolean needsWebSearch(String userText) {
        if (userText == null) {
            return false;
        }
        for (String keyword : SEARCH_KEYWORDS) {
            if (userText.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    /** 天气类关键词：命中则走心知天气准确接口，不联网搜索 */
    private static final Set<String> WEATHER_KEYWORDS = Set.of(
            "天气", "气温", "温度", "降雨", "台风", "暴雨", "下雨", "下雪",
            "晴", "多云", "阴", "湿度", "风力", "天气预报");

    private static boolean looksLikeWeatherQuestion(String userText) {
        if (userText == null) {
            return false;
        }
        for (String keyword : WEATHER_KEYWORDS) {
            if (userText.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private void requireKey() {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException(
                    "未配置阿里云百炼 API Key：请检查环境变量 DASHSCOPE_API_KEY，或在 application.properties 中设置 dashscope.api-key");
        }
    }

    private JsonNode postJson(String url, ObjectNode body) throws IOException {
        return postJson(url, body, null, null);
    }

    private JsonNode postJson(String url, ObjectNode body, String extraHeader, String extraHeaderValue) throws IOException {
        Request.Builder builder = new Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer " + apiKey)
                .addHeader("Content-Type", "application/json");
        if (extraHeader != null && extraHeaderValue != null) {
            builder.addHeader(extraHeader, extraHeaderValue);
        }
        Request request = builder
                .post(RequestBody.create(body.toString(), MediaType.get("application/json; charset=utf-8")))
                .build();
        try (Response response = http.newCall(request).execute()) {
            String text = response.body() != null ? response.body().string() : "";
            if (!response.isSuccessful()) {
                throw new IOException("HTTP " + response.code() + ": " + text);
            }
            return mapper.readTree(text);
        }
    }

    private JsonNode getJson(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer " + apiKey)
                .get()
                .build();
        try (Response response = http.newCall(request).execute()) {
            String text = response.body() != null ? response.body().string() : "";
            if (!response.isSuccessful()) {
                throw new IOException("HTTP " + response.code() + ": " + text);
            }
            return mapper.readTree(text);
        }
    }

    private byte[] download(String url) throws IOException {
        Request request = new Request.Builder().url(url).get().build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("下载失败 HTTP " + response.code());
            }
            return response.body() != null ? response.body().bytes() : new byte[0];
        }
    }

    private static String extensionOf(String url) {
        String path = url.contains("?") ? url.substring(0, url.indexOf('?')) : url;
        int dot = path.lastIndexOf('.');
        if (dot >= 0 && dot < path.length() - 1) {
            String ext = path.substring(dot).toLowerCase(Locale.ROOT);
            if (ext.matches("\\.[a-z0-9]{2,5}")) {
                return ext;
            }
        }
        return ".png";
    }

    /** 文生图结果 */
    public record ImageResult(byte[] bytes, String fileName) {
    }

    /** 对话结果：文本回复 / 图片生成提示词 / 语音播报文字 / 天气查询地点（四选一） */
    public record ChatResult(String text, String imagePrompt, String speechText, String weatherLocation) {
        public boolean wantsImage() {
            return imagePrompt != null && !imagePrompt.isBlank();
        }

        public boolean wantsSpeech() {
            return speechText != null && !speechText.isBlank();
        }

        public boolean wantsWeather() {
            return weatherLocation != null && !weatherLocation.isBlank();
        }
    }

    /** 语音合成结果（mp3 文件） */
    public record VoiceResult(byte[] bytes, String fileName) {
    }
}