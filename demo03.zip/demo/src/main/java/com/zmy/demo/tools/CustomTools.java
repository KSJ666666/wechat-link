package com.zmy.demo.tools;

import com.fasterxml.jackson.databind.JsonNode;
import com.zmy.demo.stock.StockService;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * 教学示例：自定义工具的"真实执行逻辑"。
 *
 * <p>Function Calling 中，模型只负责"决定调用哪个工具 + 填参数"，
 * 工具真正干活的代码永远由我们自己的程序实现（算数、读写、调外部 API 都在这里）。
 */
@Component
public class CustomTools {

    private final StockService stockService;

    public CustomTools(StockService stockService) {
        this.stockService = stockService;
    }

    /**
     * 按工具名分发执行，返回给模型的文本结果。
     *
     * @param name 模型要求调用的工具名
     * @param args 模型填好的参数（已从 JSON 字符串解析成 JsonNode）
     * @return 工具执行结果的文本，模型会基于它生成最终回复
     */
    public String execute(String name, JsonNode args) throws Exception {
        return switch (name) {
            case "calculate" -> calculate(args);
            case "get_time" -> getTime(args);
            case "get_stock" -> getStock(args);
            default -> throw new IllegalArgumentException("未知工具：" + name);
        };
    }

    /** 工具 1：四则运算计算器。参数：a、b（数字）、operator（+ - * /） */
    private static String calculate(JsonNode args) {
        BigDecimal a = new BigDecimal(args.path("a").asText());
        BigDecimal b = new BigDecimal(args.path("b").asText());
        String operator = args.path("operator").asText("");

        BigDecimal result = switch (operator) {
            case "+" -> a.add(b);
            case "-" -> a.subtract(b);
            case "*" -> a.multiply(b);
            case "/" -> {
                if (b.signum() == 0) {
                    throw new IllegalArgumentException("除数不能为 0");
                }
                // 除法保留 10 位小数，避免循环小数
                yield a.divide(b, 10, RoundingMode.HALF_UP).stripTrailingZeros();
            }
            default -> throw new IllegalArgumentException("不支持的运算符：" + operator);
        };

        return a.stripTrailingZeros().toPlainString() + " " + operator + " "
                + b.stripTrailingZeros().toPlainString() + " = "
                + result.stripTrailingZeros().toPlainString();
    }

    /** 工具 2：获取当前日期/时间/星期。参数：format（可选，datetime/date/time/weekday） */
    private static String getTime(JsonNode args) {
        String format = args.path("format").asText("datetime");
        LocalDateTime now = LocalDateTime.now();
        return switch (format) {
            case "date" -> LocalDate.now().toString();
            case "time" -> now.toLocalTime().withNano(0).toString();
            case "weekday" -> now.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.CHINA);
            default -> now.withNano(0).toString().replace('T', ' ');
        };
    }
    /** 工具 3：查询股票实时行情（真实数据，东方财富免费接口）。参数：symbol（股票代码） */
    private String getStock(JsonNode args) throws Exception {
        String symbol = args.path("symbol").asText("");
        if (symbol.isBlank()) {
            throw new IllegalArgumentException("symbol 参数不能为空");
        }
        return stockService.getQuote(symbol).toString();
    }

}